# Steer-DrivoR 语言分支：代码说明与运行顺序

记录日期：2026-11-09。本文对应新增的语言分支代码，方案见 `steer_drivor_qwen_gt_grounding_analysis.md`。

**`navsim/agents/drivoR/` 下的原 DrivoR 代码一行未改**，`check_drivor_vitb_backbone.py` 的源码一致性检查仍然成立。语言分支全部是新增文件。

## 1 新增文件与代码来源

| 文件 | 作用 | 复用的源代码 |
|---|---|---|
| `navsim/agents/drivoR_steer/steervit_modules.py` | CA、Connector、SoftCrossEntropyLoss | 与 SteerViT 官方 `crossattention.py`、`model.py`、`train.py` 逐字相同（已逐段比对）。唯一新增的是子类 `ScaledGatedCrossAttention`：增加外部渐入系数 s，空文本行用 `torch.where` 原样返回 |
| `navsim/agents/drivoR_steer/steer_encoder.py` | 把 CA 插进 ViT-B | 沿用 `dinov2_lora.py` 的 `__class__` 替换写法，原地改造已构建好的 `ImgEncoder`，DINOv2、LoRA、neck、GridMask 都不重建。block 循环按 SteerViT `block_forward` 写：CA 位于 norm1 之前。`RecordingGridMask` 照抄 `GridMask.forward`，只加两行用于记录遮挡图 |
| `navsim/agents/drivoR_steer/steer_model.py` | `DrivoRSteerModel` | `DrivoRModel.forward` 原样调用。文本上下文只在本次调用中交给编码器，接地 logits 在调用结束后取回 |
| `navsim/agents/drivoR_steer/steer_agent.py` | `DrivoRSteerAgent`、`GateRampCallback` | 继承 `DrivoRAgent`，Ray 打分、DrivoR 原损失和 ramp+cosine 调度均不变。新增两个参数组，并加入接地损失 |
| `navsim/agents/drivoR_steer/steer_loss.py` | 接地损失、DDP 归约 | SteerViT 的 SoftCE 与 pmass 指标 |
| `navsim/agents/drivoR_steer/steer_data.py` | 阶段 2 文本包装、阶段 1 逐相机数据集 | 图像预处理与 `DrivoRFeatureBuilder._get_camera_feature` 一致。NPZ 字段沿用 `build_grounding.pack_grounding_arrays` |
| `navsim/agents/drivoR_steer/checkpoint_utils.py` | 带检查的权重加载 | 前缀规则与 `evaluate_drivor_vitb.py` 相同 |
| `navsim/planning/script/run_training_steer.py` | 阶段 2 / D+ 训练入口 | 复制 `run_training_full.py`，只增加数据集包装 |
| `navsim/planning/script/config/common/agent/drivoR_steer.yaml` | agent 配置 | 复制 `drivoR.yaml`，追加 `steer`、`init_args`、两个学习率倍率 |
| `scripts/training/train_steer_stage1.py`、`run_steer_stage1_8gpu_dlc.sh` | 阶段 1 | 环境设置沿用 `run_drivor_vitb_8gpu_dlc.sh` |
| `scripts/training/run_steer_stage2_8gpu_dlc.sh` | 阶段 2 / D+ | 保留 D 训练时的全部 override |
| `scripts/evaluation/evaluate_drivor_steer.py`、`run_drivor_steer_navtest_1gpu.sh` | navtest 评测，支持 4 种文本模式 | 复制 `evaluate_drivor_vitb.py`，加载、PDM 打分和输出格式不变 |
| `scripts/training/check_steer_drivor.py` | 上线前用真实权重检查 | 新增 |
| `tests/test_steer_drivor_units.py` | 单元测试，用微型随机 ViT，不需要权重 | 新增 |

## 2 数据流

每个 ViT 行对应一个样本的一个相机，按 b-major 排列：`(B×4, 16 register + CLS + 3936 patch, 768)`。

- 对第 `[1,3,5,7,9,11]` 个 block（零起始），进入 block 前执行 `y ← y + s·tanh(gate)·CA(LN(y), connector(normalize(RoBERTa(该行文本))))`。
  - **方案 A（默认，`steer.ca_on_registers: false`）**：y = `[CLS | patch]`，共 3937 个 token，与 SteerViT 原版的 CA 作用范围相同。16 个 register 不被 CA 改写，只在后续自注意力中读取已被语言引导的 patch。
  - **第一版（`ca_on_registers: true`）**：y 为全部 3953 个 token，包括 register。配置中没有这个键时（方案 A 之前保存的训练配置）按第一版处理，旧 checkpoint 的评测结果不变。
- 第 i 行图像只读取第 i 行文本。文本为空或被 dropout 的行由 `torch.where` 原样返回，与 D 的视觉路径逐位相同。
- 前 16 个 register 经原 neck 送入规划器，这一部分不变。
- 3936 个 patch 经过最终 norm，再进入 SteerViT 的 `lin_seg_head`，得到接地 logits，只用于辅助损失。
- 相机顺序为 `f0, b0, l0, r0`，与 `DrivoRFeatureBuilder` 一致。文本按相机名对应（`steer_text_cam_f0` 等），不依赖列表顺序。

## 3 权重路径

| 权重 | 默认路径 | 来源 |
|---|---|---|
| DINOv2 ViT-B | `/mnt/zhaozc_workspace/project/LQH/DINVO2_SteerViT/model.safetensors` | `drivoR.yaml` |
| checkpoint D | `exp/ke/training_drivoR_Nav1_vitb_8gpu_b16_25epochs/11.07_03.36/lightning_logs/version_0/checkpoints/best-epoch=23-step=19344.ckpt` | `docs/checkpoints.md`（Git LFS） |
| RoBERTa-large | `/mnt/zhaozc_workspace/project/LQH/RoBERTa` | 数据生成脚本的默认值 |
| SteerViT | `$REPO_ROOT/SteerViT_checkpoint/steervit_dinov2_base.pth` | `vitb_backbone_swap.md` 只写了相对路径。**请确认**，不对时用 `STEERVIT_CHECKPOINT=` 覆盖 |
| 阶段 1 数据 | `/mnt/zhaozc_workspace/project/LQH/Driv-calude_data/DrivoR-main/outputs/stage1_navtrain_8gpu_full` | `stage1_empty_gt_fix.md`；用 `STAGE1_BUNDLE=` 覆盖 |
| 阶段 2 数据 | 无默认值，必须设置 `STAGE2_BUNDLE=` | stage2_focus 全量输出根目录，需含 train/val/test 三个划分 |

启动脚本会检查 D 的大小，防止误用 Git LFS 指针文件。

## 4 运行顺序

```bash
cd /mnt/zhaozc_workspace/project/LQH/Drivor-orial/DrivoR-main   # 或本仓库的服务器路径
source /mnt/zhaozc_workspace/envs/drivorpython/bin/activate
export PYTHONPATH=$PWD:$PWD/nuplan-devkit

# 0) 单元测试（CPU，几十秒）
python tests/test_steer_drivor_units.py

# 1) 真实权重检查（单卡）：加载覆盖、空文本==D、s=0==D、逐相机路由、样本交换
python scripts/training/check_steer_drivor.py --device cuda:0 --output exp/steer_check_init.json

# 2) 阶段 1（先 --dry-run 看命令）
bash scripts/training/run_steer_stage1_8gpu_dlc.sh --dry-run
bash scripts/training/run_steer_stage1_8gpu_dlc.sh
#    若已对阶段 1 标签做了"最近 n 框 / 覆盖 40% / 去 barrier"的修正：GROUNDING_OVERRIDE=<修正后的 masks 目录>

# 3) 用阶段 1 权重再检查一次（同时确认阶段 1 用的是同一个 D）
python scripts/training/check_steer_drivor.py --stage1-checkpoint exp/steer_stage1/checkpoints/<best>.ckpt

# 4) 阶段 2
STAGE2_BUNDLE=<stage2_focus 输出> STAGE1_CHECKPOINT=exp/steer_stage1/checkpoints/<best>.ckpt \
  bash scripts/training/run_steer_stage2_8gpu_dlc.sh

# 5) D+ 对照：BATCH_SIZE、MAX_EPOCHS 与第 4 步相同
STEER_ENABLED=false bash scripts/training/run_steer_stage2_8gpu_dlc.sh

# 6) navtest：同一个 checkpoint 跑 4 种文本模式；D+ 用 TEXT_MODE=none
for m in correct empty shuffle swap_f0_b0; do
  CHECKPOINT=<阶段2 best.ckpt> TEXT_INDEX=<stage2_focus>/test/dataset_index.jsonl TEXT_MODE=$m \
    bash scripts/evaluation/run_drivor_steer_navtest_1gpu.sh
done
CHECKPOINT=<D+ best.ckpt> TEXT_MODE=none bash scripts/evaluation/run_drivor_steer_navtest_1gpu.sh
```

第 1 步的期望结果：`empty_text_equals_D`、`gate_scale_0_equals_D` 的各项差值都为 0。各相机的 `other_rows_max_diff` 为 0，`text_row_changed` 大于 0。

`swap_samples` 只交换了 batch 中样本的顺序。如果 GPU 内核导致约 1e-6 的差异，可以加 `--tolerance 1e-5` 重跑，并记录这个容差。

第 1、3 步的差值必须严格为 0。若不为 0，说明空文本路径或权重加载有问题，不要开始训练。

## 5 默认超参

| 项 | 默认 | 依据 / 说明 |
|---|---|---|
| CA 层 | `[1,3,5,7,9,11]`，`use_ffn=false` | 加载时与 SteerViT checkpoint 自带的 config 核对，不一致直接报错 |
| 阶段 1 | 每卡 32 个相机行，lr 1e-4，5% warmup 后 cosine 降到 0.1 倍，梯度裁剪 1.0，2 epoch，按 val/pmass 选 best | SteerViT 的 lr 范围为 3e-4→3e-5，`max_grad_norm=1.0`。D 冻结，GridMask 关闭，s=1 |
| 阶段 2 学习率 | DrivoR 参数 `0.0002·√(128/64)·0.1 = 2.83e-5`；CA、connector、分割头再乘 0.1，为 `2.83e-6` | 方案中的推荐范围下限；`D_LR_SCALE`、`STEER_LR_SCALE` 可改 |
| 阶段 2 长度 | 8 epoch | 约为 D 的三分之一；`MAX_EPOCHS` 可改，D+ 必须使用相同值 |
| 门控渐入 | 前 10% 调度步，s 从 0 线性升到 1 | 与 LR warmup 等长。s 作为 buffer 保存在 checkpoint 中。评测脚本要求 s=1，防止误用渐入期间的 checkpoint |
| 损失 | `L_DrivoR + 0.5·s·L_ground` | s=0 时接地项为 0 |
| text dropout | 0.2，以样本为单位，四个相机同时置空 | 被 dropout 的相机既跳过 CA，也跳过接地损失 |
| GridMask | 阶段 2 默认关闭（`steer.grid_mask: false`），完整方法与 D+ 共用这一设置 | 见第 6 节 |
| CA 作用范围 | 方案 A：只作用于 `[CLS | patch]`（`steer.ca_on_registers: false`） | 见第 8 节 |

## 6 实现约定

- **加载 D**：去掉 `agent._drivor_model.` 前缀后加载。只允许缺少语言模块的 key，不允许出现 unexpected key；加载后逐个张量与 D 比较数值。不恢复 D 的 optimizer、scheduler 和 step。
- **加载 SteerViT**：每个 CA、connector 和分割头都用 `strict=True` 加载。`textPE` 在官方 forward 中没有被使用，这里跳过并写入报告。
- **加载阶段 1 checkpoint**：只取语言模块。同时核对其中保存的 D 部分与当前 D 逐项相等，不相等就报错。
- **RoBERTa**：冻结，用 fp32 推理并关闭 autocast。它不注册为子模块，因此不会进入 checkpoint、optimizer 或 DDP，在首次 forward 时移到对应的卡上。
- **GridMask 与接地**：一次前向中所有图像共用同一张遮挡图。被完全遮挡的 patch 不参与 softmax。目标乘以每个 patch 的保留比例后重新归一化。这是方案允许的 patch 级近似，没有把部分遮挡 patch 内的保留像素与框求交。目标被完全遮住的相机跳过损失。
- **DDP**：接地损失按全部卡上的有效相机数取平均，任何一张卡没有有效相机都不会产生 NaN。所有语言模块每一步都参与计算图，因此不需要 `find_unused_parameters`。
- **数据缺失**：阶段 2 训练集和验证集中的每个 scene 都必须有文本，否则报错；只在调试时设置 `+steer_data.allow_missing=true`。navtest 评测同样要求全覆盖。
- **评测扰动**：`shuffle` 用固定种子做无自匹配的 scene 置换，供体的四句文本一起移动；`swap_f0_b0` 只交换前后视文本。置换表和有效子集写入 `text_mode.json`。

## 7 尚未验证 / 需要你确认

1. 本机没有 torch，无法执行任何张量代码。已完成的检查：
   - ruff 静态检查和全部文件编译；
   - 复制代码与 SteerViT、GridMask 原文逐段比对，GridMask 只多两行；
   - 用替身 torch 跑了文本索引、阶段 1 样本构建和 4 种评测文本模式的纯 Python 测试，全部通过。

   **单元测试和第 1 步检查必须先在服务器上跑通。**
2. SteerViT checkpoint 的绝对路径。
3. 阶段 1 是否需要使用修正后的接地标签（`GROUNDING_OVERRIDE`）。
4. 显存只是估算。D 每卡 batch 16 约 66 GiB；CA 的激活约增加 10～15 GiB，RoBERTa 约 1.4 GiB，合计在 96 GB 卡上应能放下，但没有实测。若 OOM，阶段 2 和 D+ 需要一起降低 `BATCH_SIZE`。
5. stage2_focus 全量的 train、val、test 都需要有 `COMPLETE.json`，启动脚本会检查。

## 8 方案 A：CA 不写入 register

**动机**：第一版第二阶段在第 1 个 epoch 的验证分数比 D+ 低约 4.5 分，规划损失在门控 s 上升期间明显变大。第一版中 CA 直接改写规划器读取的 16 个 register；方案 A 让 register 只通过自注意力间接获得语言信息。

**改动**（参数完全不变，旧的阶段 1 和阶段 2 checkpoint 都能严格加载）：
- `steer_encoder.py`：`timm_ViT_Steer.forward_features` 中，方案 A 对 `x[:, 16:]`（CLS + patch）做 CA，再与原样保留的 `x[:, :16]` 拼回。空文本行和 s=0 仍与 D 逐位相同。
- `drivoR_steer.yaml`：新增 `ca_on_registers: false`。
- 阶段 1 checkpoint 会记录训练时的 CA 模式（`steer_meta`）；阶段 2 加载时若模式不一致会打印警告，初始化报告中也会写明。
- 启动脚本新增 `CA_ON_REGISTERS`（默认 `false`）。方案 A 的阶段 1 输出到 `exp/steer_stage1_capatch`，阶段 2 的实验名为 `steer_stage2_capatch_*`，与第一版分开，不会误接第一版的 checkpoint 续训。D+ 不受影响，无需重跑。
- `train_steer_stage1.py train --validate-ckpt <ckpt>`：只对给定的阶段 1 checkpoint 做验证（loss / pmass），可用 `--ca-on-registers` 指定模式。
- `check_steer_drivor.py` 新增第 7 项检查：每个 CA 层收到的 token 数（方案 A 为 3937，第一版为 3953）。
- 评测脚本的 `summary.json` 和 `provenance.json` 记录 `ca_on_registers`；D+ 的 `text_mode` 记为 `none (D+)`。

**是否需要重训阶段 1**：参数相同，第一版阶段 1 的权重可以直接作为方案 A 的初始化。区别只在于训练时 patch 能否通过自注意力看到被 CA 改过的 register。先用 `--validate-ckpt` 在方案 A 下验证现有的阶段 1 best：若 `val/pmass` 与原来相差不到 1 个百分点，直接复用；否则在方案 A 下重训阶段 1。

## 9 从头训练：有语言 L 与无语言 B0

两个模型都按训练 D 时的方式初始化，不加载 D 的任何权重：DINOv2 ViT-B 预训练权重、新建的 LoRA（B=0，所以第 0 步的 ViT 就是原版 DINOv2）、随机初始化的 register、neck 和两个 decoder。训练配方也和 D 相同：25 个 epoch，每卡 16、共 8 卡，base_lr 2e-4，seed 2，其余 DrivoR 参数逐项一致。两个模型只在语言分支上不同：

| | B0 | L |
|---|---|---|
| CA、Connector、分割头 | 无 | SteerViT 官方权重，峰值学习率 2.3e-5 |
| CA 作用范围 | — | 方案 A（CLS + patch） |
| 损失 | 轨迹 + 打分 | 轨迹 + 打分 + 0.5 × 接地（s=1，不渐入） |
| text dropout | — | 0.2 |
| GridMask | 关 | 关 |

与 D 相比的两处共同变化：
- GridMask 关闭。所以 D 不能直接当基线，B0 需要重新训练。
- 调度器按真实步数计算（`scheduler_args.exact_steps`）。D 的配置把样本数写成 85,000，25 个 epoch 只算到 16,625 步，最后约 20% 的步数里学习率会回升。现在由 `run_training_steer.py` 按实际样本数算出每个 epoch 的步数（25 个 epoch 约 20,150 步），训练开始时会打印并与 Lightning 的实际步数核对。

同一个种子下，L 和 B0 的共享参数初始值逐位相同：语言模块是在 DrivoR 模型构建完成之后才加上的。每个 epoch 的 checkpoint 都会保留（`keep_all_epochs`），文件名为 `epoch=X-step=Y.ckpt`。

新增与修改：
- `checkpoint_utils.initialise_training_weights`：`init_args.from_scratch=true` 时不加载 D，也拒绝阶段 1 checkpoint（它包含 D）；L 从 SteerViT 加载语言模块。
- `schedule_utils.py`：精确步数和参数分组。`lr_args.steer_lr` 为语言模块的绝对学习率。
- `scripts/training/run_scratch_8gpu_dlc.sh`：`MODEL=lang` / `MODEL=base`。
- `scripts/training/check_scratch_init.py`：上线前用真实权重检查，包括共享参数初始值相同、LoRA B 为 0、SteerViT 权重已加载、GridMask 关闭、空文本时 L 与 B0 逐位相同、参数分组。

评测：用 `evaluate_drivor_steer.py` 在全量 navtest 上评测。L 跑 correct、empty、shuffle、swap_f0_b0 四种文本模式；B0 用 `TEXT_MODE=none`。差距小于约 0.5 分时，建议补跑第二个种子。

## 10 方案 1：语言模块冻结在官方权重，不用接地损失（`MODEL=lang_frozen`）

为什么要改：逐级对比（`scripts/viz/compare_grounding_stages.py`，2026-11-19）显示，官方 SteerViT、pure（DINOv2 + 官方权重，1148×672）和 init（D + 官方权重）都能按颜色词换车；阶段 1 训练之后就不能了。原因是阶段 1、阶段 2 的接地标签按"该类别最近的 n 个框"生成，颜色和方位词从不改变目标。所以先不用这套标签，让语言模块保持官方权重。

| | B0 | L（`lang`，第 9 节） | L-冻结（`lang_frozen`） |
|---|---|---|---|
| CA（含 tanh 门控）、Connector、分割头 | 无 | 官方权重起步，学习率 2.3e-5 | 官方权重，**冻结**，不进优化器 |
| 接地损失 | — | 0.5 × 接地 | **无**，`grounding_npz` 不读取 |
| 注入强度 s | — | 1 | 1（不渐入） |
| LoRA、register、neck、decoder | 学习率 2e-4×√2 | 同 B0 | 同 B0，优化器参数组与 B0 完全相同 |
| 文本、text dropout 0.2、方案 A、GridMask 关、种子 2、25 epoch、精确步数 | — | 同 | 同 |

配置开关（`drivoR_steer.yaml` 的 `steer` 下；缺省值即原行为，旧配置和旧 checkpoint 不受影响）：
- `grounding: false`：`DrivoRSteerAgent.compute_loss` 只返回 DrivoR 原损失；`run_training_steer.py` 把 `with_grounding=false` 传给 `SteerTextDataset`，文本照常读取。
- `freeze_steer_modules: true`：`SteerImgEncoder.freeze_steer_modules()` 把 `steer_parameters()`（CA、门控、Connector、分割头）设为 `requires_grad=False`，`build_param_groups` 本来就跳过冻结参数，因此没有 steer 参数组。每个训练 epoch 结束时，`FrozenSteerCheckCallback` 在日志里打印这些张量是否与训练开始时逐位相同。
- 只关接地、不冻结（以后的做法 B）时，只冻结分割头，因为它没有任何梯度。

数据：不需要改。`dataset_index.jsonl` 照常提供每个相机的 `scene_text`；`grounding_npz` 留着，只是不读。

检查与运行：
```
python scripts/training/check_scratch_init.py --model lang_frozen --output scratch_init_check_frozen.json
MODEL=lang_frozen bash scripts/training/run_scratch_8gpu_dlc.sh
```
`check_scratch_init.py --model lang_frozen` 额外检查：所有 steer 张量 `requires_grad=False`，优化器只有一个参数组，并且与 B0 的参数量和学习率完全相同。B0 不需要重跑。

训练中途和结束后，用 `scripts/viz/run_compare_grounding_stages.sh`（`STAGE2_CHECKPOINT=<该 run 的 epoch checkpoint>`）检查定位能力是否还在：脚本会从 run 配置里识别从头训练，自动只画 official / pure / scratch 三行。LoRA 仍在训练，可能削弱定位，这一步用来确认。
